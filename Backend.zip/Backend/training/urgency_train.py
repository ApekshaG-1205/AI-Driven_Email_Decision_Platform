from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from utils import load_data
import joblib
import os

# Load data
df = load_data("processed_data.csv")

# Define X and y
X = df["text"]
y = df["urgency"]

# SPlit data
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Vectorize AFTER split (prevents leakage)
vectorizer = TfidfVectorizer(
    max_features=5000,
    ngram_range=(1, 2),
    min_df = 5  # improvement
)

X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Model
model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X_train_vec, y_train)

# Predictions
y_pred = model.predict(X_test_vec)

# Evaluation
print("Urgency Model Report:")
print(classification_report(y_test, y_pred))
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

joblib.dump(model, "../ml_models/urgency.pkl")
joblib.dump(vectorizer, "../ml_models/urgency_vectorizer.pkl")

# Save
# model_dir = "../ml_models"
# os.makedirs(model_dir, exist_ok=True)

# joblib.dump(model, os.path.join(model_dir, "sentiment.pkl"))
# joblib.dump(vectorizer, os.path.join(model_dir, "sentiment_vectorizer.pkl"))

print("Model saved successfully ")