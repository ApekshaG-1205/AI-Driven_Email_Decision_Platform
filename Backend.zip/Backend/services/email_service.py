from models.model_loader import model_registry
from schemas.email_schema import EmailAnalysisResult
from utils.text_utils import clean_text
from core.logging import logger
from utils.email_rules import detect_department, enhance_urgency, enhance_risk



def _derive_final_decision(intent: str, sentiment: str, urgency: str, risk: str, department: str) -> str:
    urgency_low = urgency.lower()
    risk_low = risk.lower()
    sentiment_low = sentiment.lower()

    if risk_low in ("high", "critical"):
        return f"Block – high-risk content detected. Route to {department} with manual review."

    if urgency_low in ("high", "critical"):
        if sentiment_low == "negative":
            return f"Escalate immediately to {department} – urgent and negative tone detected."
        return f"Escalate to {department} – high urgency request detected."
    
    if urgency_low == "medium":
        if sentiment_low == "negative":
            return f"Prioritize to {department} – moderate urgency with negative sentiment."
        return f"Prioritize to {department} – moderate urgency request."


    if sentiment_low == "negative":
        return f"Flag for review by {department} – negative sentiment detected."

    if intent.lower() in ("complaint", "threat", "spam"):
        return f"Route to {department} – intent classified as '{intent}'."

    return f"Auto-process via {department} – low risk, normal priority email."



class EmailAnalysisService:
    def analyze(self, raw_text: str) -> EmailAnalysisResult:
        if not model_registry.is_ready:
            raise RuntimeError("Model registry is not initialized.")

        cleaned = clean_text(raw_text)
        if not cleaned:
            raise ValueError("Email text is empty after preprocessing.")

        logger.info("Running analysis pipeline (length=%d)", len(cleaned))

        # ML predictions
        intent    = model_registry.get("intent").predict(cleaned)
        sentiment = model_registry.get("sentiment").predict(cleaned)
        urgency_ml = model_registry.get("urgency").predict(cleaned)
        risk_ml    = model_registry.get("risk").predict(cleaned)

        # Hybrid improvements
        urgency = enhance_urgency(cleaned, urgency_ml)
        risk    = enhance_risk(cleaned, risk_ml)

        # Department detection
        department = detect_department(cleaned)

        logger.info(
            "intent=%s sentiment=%s urgency=%s risk=%s department=%s",
            intent, sentiment, urgency, risk, department
        )

        return EmailAnalysisResult(
            intent=intent,
            sentiment=sentiment,
            urgency=urgency,
            risk=risk,
            department=department,   
            final_decision=_derive_final_decision(intent, sentiment, urgency, risk, department)
        )


email_service = EmailAnalysisService()