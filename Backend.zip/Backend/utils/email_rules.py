def detect_department(text: str) -> str:
    text = text.lower()

    if any(word in text for word in ["salary", "pay", "payslip", "bonus", "compensation"]):
        return "Payroll"

    elif any(word in text for word in ["leave", "vacation", "policy", "attendance", "hr"]):
        return "HR"

    elif any(word in text for word in ["error", "bug", "system", "login", "crash", "issue"]):
        return "IT Support"

    elif any(word in text for word in ["approval", "manager", "deadline", "project"]):
        return "Manager"

    elif any(word in text for word in ["price", "quote", "purchase", "order"]):
        return "Sales"

    return "General"


# Hybrid Urgency
def enhance_urgency(text: str, ml_prediction: str) -> str:
    text = text.lower()

    high_keywords = [
        "urgent", "asap", "immediately", "right now", "critical",
        "deadline today", "within hours", "emergency"
    ]

    medium_keywords = [
        "soon", "as early as possible", "priority",
        "important", "need this", "please respond"
    ]

    low_keywords = [
        "whenever possible", "no hurry", "no rush", "take your time"
    ]

    # HIGH priority override
    if any(word in text for word in high_keywords):
        return "high"

    # MEDIUM logic
    if any(word in text for word in medium_keywords):
        return "medium"

    # LOW override
    if any(word in text for word in low_keywords):
        return "low"

    # fallback to ML
    if ml_prediction.lower() == "high":
        return "medium"   # soften it (important!)
    
    return "low"



# Hybrid Risk
def enhance_risk(text: str, ml_prediction: str) -> str:
    text = text.lower()

    if any(word in text for word in ["legal", "lawsuit", "complaint", "escalate"]):
        return "high"

    if any(word in text for word in ["issue", "problem", "not satisfied"]):
        return "medium"

    return ml_prediction
